Contributors
============
hugo-vitae is an open source project in development and lives from the
collaboration of others.

*Please edit this list to include new contributors.*

* [Benedikt Tuchen](https://github.com/dataCobra)
* [Mark Petherbridge](https://github.com/markdevjapan)
* [Christoph Petrausch](https://github.com/hikhvar)
* [Mohamed Muhannad](https://github.com/muhannad0)
* [Jon Besga](https://github.com/jonbesga)
* [Mochammad Ihza Rizky Karim](https://github.com/ihzarizkyk)
* [Bernardo Ayala](https://github.com/nardoyala)
* [Mattia Panzeri](https://github.com/panz3r)
* [Jörg Thalheim](https://github.com/Mic92)
* [David Kaufmann](https://github.com/davidkaufmann)
* [Sarath Chandra Mekala](https://github.com/sarathmekala)
* [Jeff Schoner](https://github.com/jeffschoner)
